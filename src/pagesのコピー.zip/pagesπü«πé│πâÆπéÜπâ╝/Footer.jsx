import React, { useState } from 'react';


export default function Footer() {


  return (
    <div className='footer' id='footer'>
      <div className='footer_container'>
        <p>Lean Copyright © 2023 Lean Co., Ltd. <br className="dn-for-pc" /> All Rights Reserved.</p>
      </div>
    </div>
  );
}
